﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp1
{
    internal class EditManagerComponent
    {
        MySqlConnection sqlConnection;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;
        MySqlDataReader sqlDataReader;
        public Button btnUpdateManager = new Button();
        public Control[] editManagerComponent() {

            Label lblTeam = new Label
            {
                Name = "lblTeam",
                Location = new Point(50, 30),
                Size = new Size(90, 30),
                Text = "Team :"
            };
            

            ComboBox comboTeam = new ComboBox
            {
                Name = "comboTeam",
                Location = new Point(140, 30),
                Size = new Size(100, 30),
                DropDownStyle = ComboBoxStyle.DropDownList,
                

            };
    
            

            DataGridView dgvManager = new DataGridView { 
                Name = "dgvManager",
                Location = new Point(50, 100),
                Size = new Size(600, 300),
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
            };

            Label lblFreeMan = new Label
            {
                Name = "lblTeam",
                Location = new Point(50, 430),
                Size = new Size(150, 30),
                Text = "Free Manager :"
            };

            DataGridView dgvFreeManager = new DataGridView
            {
                Name = "dgvFreeManager",
                Location = new Point(50, 480),
                Size = new Size(600, 300),
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,

            };



            //Create Button Add Player

            btnUpdateManager.Name = "btnUpdateManager";
            btnUpdateManager.Location = new Point(150, 800);
            btnUpdateManager.Size = new Size(150, 30);
            btnUpdateManager.Text = "Update Manager";
            


            return new Control[] { lblTeam, comboTeam, dgvManager, lblFreeMan, dgvFreeManager, btnUpdateManager};
        }

       

     }
}
