﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp1
{
    internal class AddPlayerComponent
    {
        public Button btnAddPlayer = new Button();
        public Control[] AddComponentPlayer()
        {
            Label lblBirth = new Label
            {
                Name = "lblBirth",
                Location = new Point(300, 30),
                Size = new Size(90, 30),
                Text = "Birthday :"
            };
            DateTimePicker dateTimePicker = new DateTimePicker { 
                Name = "DateTime",
                Location = new Point(400,30)

            };
            
            // Create a new Label control
            Label labelID = new Label();

            // Set the properties of the textbox
            labelID.Name = "lblID";
            labelID.Text = "ID :";
            labelID.Size = new Size(90, 30);
            labelID.Location = new Point(30, 30);

            // Add the textbox to the form
            //panel1.Controls.Add(labelID);

            // Create a new TextBox control
            TextBox txtID = new TextBox();

            // Set the properties of the textbox
            txtID.Name = "txtID";
            txtID.Text = "";
            txtID.Size = new Size(100, 30);
            txtID.Location = new Point(150, 30);

            // Add the textbox to the form
            //panel1.Controls.Add(txtID);

            //===========================ShortHand=========================================
            //Create a new Label (Name, Height, Weight, Team, Nationality, Position, Number, Addbutton
            Label lblName = new Label
            {
                Name = "lblName",
                Location = new Point(30, 60),
                Size = new Size(90, 30),
                Text = "Name :"
            };
            //panel1.Controls.Add(lblName);

            TextBox txtName = new TextBox
            {
                Name = "txtName",
                Location = new Point(150, 60),
                Size = new Size(100, 30),
                Text = ""
            };
            //panel1.Controls.Add(txtName);

            //Create Height 
            Label lblHeight = new Label
            {
                Name = "lblHeight",
                Location = new Point(30, 90),
                Size = new Size(90, 30),
                Text = "Height :"
            };
            //panel1.Controls.Add(lblHeight);

            TextBox txtHeight = new TextBox
            {
                Name = "txtHeight",
                Location = new Point(150, 90),
                Size = new Size(100, 30),
                Text = ""
            };
            //panel1.Controls.Add(txtHeight);

            //Create Weight 
            Label lblWeight = new Label
            {
                Name = "lblWeight",
                Location = new Point(30, 120),
                Size = new Size(90, 30),
                Text = "Weight :"
            };
            //panel1.Controls.Add(lblWeight);

            TextBox txtWeight = new TextBox
            {
                Name = "txtWeight",
                Location = new Point(150, 120),
                Size = new Size(100, 30),
                Text = ""
            };
            //panel1.Controls.Add(txtWeight);

            //Create Combo Team
            Label lblTeam = new Label
            {
                Name = "lblTeam",
                Location = new Point(30, 150),
                Size = new Size(90, 30),
                Text = "Team :"
            };
            //panel1.Controls.Add(lblTeam);

            ComboBox comboTeam = new ComboBox
            {
                Name = "comboTeam",
                Location = new Point(150, 150),
                Size = new Size(100, 30),
                DropDownStyle = ComboBoxStyle.DropDownList

            };
            //panel1.Controls.Add(comboTeam);

            //Create Combo Nationality
            Label lblNationality = new Label
            {
                Name = "lblNationality",
                Location = new Point(30, 180),
                Size = new Size(90, 30),
                Text = "Nationality :"
            };
            //panel1.Controls.Add(lblNationality);

            ComboBox comboNationality = new ComboBox
            {
                Name = "comboNationality",
                Location = new Point(150, 180),
                Size = new Size(100, 30),
                DropDownStyle = ComboBoxStyle.DropDownList

            };
            //panel1.Controls.Add(comboNationality);

            //Create Combo Position
            Label lblPosition = new Label
            {
                Name = "lblPosition",
                Location = new Point(30, 210),
                Size = new Size(90, 30),
                Text = "Position :"
            };
            //panel1.Controls.Add(lblPosition);

            ComboBox comboPosition = new ComboBox
            {
                Name = "comboPosition",
                Location = new Point(150, 210),
                Size = new Size(100, 30),
                DropDownStyle = ComboBoxStyle.DropDownList

            };
            //panel1.Controls.Add(comboPosition);

            //Create Number
            Label lblNumber = new Label
            {
                Name = "lblNumber",
                Location = new Point(30, 240),
                Size = new Size(90, 30),
                Text = "Number :"
            };
            //panel1.Controls.Add(lblNumber);

            TextBox txtNumber = new TextBox
            {
                Name = "txtNumber",
                Location = new Point(150, 240),
                Size = new Size(100, 30),
                Text = ""
            };
            //panel1.Controls.Add(txtNumber);

            //Create Button Add Player

            btnAddPlayer.Name = "btnAdd";
            btnAddPlayer.Location = new Point(150, 300);
            btnAddPlayer.Size = new Size(150, 30);
            btnAddPlayer.Text = "Add Player";

            //panel1.Controls.Add(btnAddPlayer);
            Control[] controls = new Control[] { txtID, txtName, txtHeight,txtWeight,txtNumber, comboNationality, comboPosition, comboTeam, btnAddPlayer, lblHeight, labelID, lblName,lblNationality,lblNumber,lblPosition,lblTeam,lblWeight, dateTimePicker, lblBirth };
            return controls;

        }
    }
}
